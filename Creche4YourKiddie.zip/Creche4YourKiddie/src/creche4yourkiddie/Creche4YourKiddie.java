
package creche4yourkiddie;

public class Creche4YourKiddie {

    public static void main(String[] args) {
        // TODO code application logic here
        new YourKiddie();
    }
    
}

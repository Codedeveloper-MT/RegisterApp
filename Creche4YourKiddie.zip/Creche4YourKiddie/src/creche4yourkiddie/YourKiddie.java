package creche4yourkiddie;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class YourKiddie extends JFrame implements ActionListener{

    //lbl
    private JLabel lblName;
    private JLabel lblGender;
    
    //pnl
    private JPanel pnlMenu;
    private JPanel pnlname;
    private JPanel pnlTextArea;
    private JPanel pnlRadiobtns;
    private JPanel pnlbuttons;
    
    //tf
    private JTextField tfName;
    
    //rdbtn
    private JRadioButton rdbtnMale;
    private JRadioButton rdbtnFemale;
    
     
    //btn
    private JButton btnRegister;
    private JButton btnDisplay;
     
    //ta
    private JTextArea taDisplay;
    private JScrollPane spDispay;
    
    private ArrayList<String> kidList;
    
    public YourKiddie() {
        
         kidList = new ArrayList<>();
         
        pnlMenu = new JPanel(new GridBagLayout());
        pnlname = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlRadiobtns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlbuttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlTextArea = new JPanel(new FlowLayout());

        GridBagConstraints SetLayout = new GridBagConstraints();
        SetLayout.insets = new java.awt.Insets(10, 10, 10, 10); // Padding around components
        SetLayout.fill = GridBagConstraints.HORIZONTAL;
        SetLayout.gridx = 0;
        SetLayout.gridy = 0;

        //for kids name
        lblName = new JLabel();
        lblName.setText("Name:");
        tfName = new JTextField();
        tfName.setPreferredSize(new Dimension(250, 40));
        pnlname.add(lblName);
        pnlname.add(tfName);
        
        // Add pnlname to pnlMenu with GridBagConstraints
        SetLayout.gridx = 0;
        SetLayout.gridy = 0;
        SetLayout.gridwidth = 2;
        SetLayout.weightx = 1;
        pnlMenu.add(pnlname, SetLayout);

        //for gender
        lblGender = new JLabel();
        lblGender.setText("Gender:");
        rdbtnMale = new JRadioButton("Male");
        rdbtnFemale = new JRadioButton("Female");
        lblGender.setPreferredSize(new Dimension(100, 40));
        rdbtnMale.setPreferredSize(new Dimension(100, 50));
        rdbtnFemale.setPreferredSize(new Dimension(100, 50));
        rdbtnFemale.addActionListener(this);
        rdbtnMale.addActionListener(this);
        ButtonGroup group=new ButtonGroup();
        group.add(rdbtnMale);
        group.add(rdbtnFemale);
        pnlRadiobtns.add(lblGender);
        pnlRadiobtns.add(rdbtnMale);
        pnlRadiobtns.add(rdbtnFemale);
        
        
        // Add pnlRadiobtns to pnlMenu with GridBagConstraints
        SetLayout.gridx = 0;
        SetLayout.gridy = 1;
        pnlMenu.add(pnlRadiobtns, SetLayout);

        //for buttons
        btnRegister = new JButton("Register kiddio");
        btnDisplay = new JButton("Display kiddio");
        pnlbuttons.add(btnRegister);
        pnlbuttons.add(btnDisplay);
        btnDisplay.setPreferredSize(new Dimension(200, 50));
        btnRegister.setPreferredSize(new Dimension(200, 50));
        btnDisplay.addActionListener(this);
        btnRegister.addActionListener(this);
        
        // Add pnlbuttons to pnlMenu with GridBagConstraints
        SetLayout.gridx = 0;
        SetLayout.gridy = 2;
        pnlMenu.add(pnlbuttons, SetLayout);

        //for displaying
        taDisplay = new JTextArea(20, 40);
        taDisplay.setBackground(Color.WHITE);
        taDisplay.setPreferredSize(new Dimension(500, 400));
        taDisplay.setEditable(false);
        taDisplay.setLineWrap(true);
        taDisplay.setWrapStyleWord(true);
      
        
        spDispay = new JScrollPane(taDisplay, 
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, 
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        // Add spDispay to pnlMenu with GridBagConstraints
        SetLayout.gridx = 0;
        SetLayout.gridy = 3;
        SetLayout.gridwidth = 2;
        SetLayout.weightx = 1;
        SetLayout.weighty = 1;
        SetLayout.fill = GridBagConstraints.BOTH;
        pnlMenu.add(spDispay, SetLayout);
        
        this.setVisible(true);
        this.setTitle("Creche 4 Your Kiddie");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setSize(600, 650);
        this.setContentPane(pnlMenu);
        this.pack();
     
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnRegister) {
            registerKiddie();
        } else if (e.getSource() == btnDisplay) {
            displayKiddie();
        }
        
        // Handling radio button selections
        else if (e.getSource() == rdbtnMale) {
            System.out.println("Male");
        } else if (e.getSource() == rdbtnFemale) {
            System.out.println("Female");
        }
    }

         private void registerKiddie() {
        if (tfName.getText().isEmpty() || (!rdbtnMale.isSelected() && !rdbtnFemale.isSelected())) {
            JOptionPane.showMessageDialog(null, "Enter Missing Information!");
        } else {
           String gender;
            if (rdbtnMale.isSelected()) {
                gender = "Male";
            } else {
                gender = "Female";
            }

            String name = tfName.getText();
              String kidDetails = "Name: " + name + ", Gender: " + gender;
            kidList.add(kidDetails);
            
            tfName.setText(" ");
           rdbtnMale.setSelected(false);
            rdbtnFemale.setSelected(false);
            // Write to a text file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("kiddie_info.txt", true))) {
                writer.write(kidDetails);
                writer.newLine();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "can not write to a file: " + e.getMessage());
            }
        }
    }

        private void displayKiddie() {
        String content = "";
        try (BufferedReader reader = new BufferedReader(new FileReader("kiddie_info.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content += line + "\n"; 
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading from file: " + e.getMessage());
        }
        taDisplay.setText(content);
    }

        
    }

   


